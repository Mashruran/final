<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spider Plant</title>
    <link rel="stylesheet" href="assets/css/plantstyle.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/newstyles.css">
</head>
<body>
<header class="header" id="header">
    <nav class="nav container">
        <a href="#" class="nav__logo">
            <i class="ri-leaf-line nav__logo-icon"></i> BlueLeaf
        </a>

        <div class="nav__menu" id="nav-menu">
            <ul class="nav__list">
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link active-link">Home</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">About</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">Products</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FAQs</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FEEDBACK</a>
                </li>
            </ul>

            <div class="nav__close" id="nav-close">
                <i class="ri-close-line"></i>
            </div>
        </div>

        <div class="nav__btns">
            <!-- Theme change button -->
            <i class="ri-moon-line change-theme" id="theme-button"></i>

            <div class="nav__toggle" id="nav-toggle">
                <i class="ri-menu-line"></i>
            </div>
        </div>
    </nav>
</header>
    <div class="sectionPlant">
        <div class="text">
            <h1>Spider Plant</h1>
            <!-- <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Modi voluptates, porro exercitationem quod recusandae, voluptatem maiores facere cumque nesciunt atque deleniti incidunt fugiat minus. Sit, architecto! Optio mollitia nobis animi libero dolore tenetur? Amet! -->
                <details>
                    <summary>Description</summary>
                    <p>Spider plants produce a rosette of long, thin, arched foliage that is solid green or variegated with white. These easy-to-grow houseplants look especially nice in a hanging basket and were a favorite in Victorian-era households.</p>
</details>
<details>
                    <summary>Care Guide</summary>
                    <p>Spider plant needs are simple: Place the plant in bright to moderate light in a room that's a comfortable temperature for everyone. Keep the soil slightly moist. Once-a-week watering is sufficient in spring and summer; in winter, allow the soil to dry a bit more between waterings.</p>
</details>
<details>
                    <summary>Sad plant sign</summary>
                    <p>A dying spider plant is usually because of root rot due to over watering which turns the leaves yellow and causes the spider plant to droop with a dying appearance. Low humidity and excess fertilizer can cause the spider plants leaf tips to turn brown and die back.
</p>
</details>
        </div>
        <img src="assets/img/plant1.jpg" alt=""/>
    </p>
    </div>
</body>
</html>