<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aloe Vera Plant</title>
    <link rel="stylesheet" href="assets/css/plantstyle.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/newstyles.css">
</head>
<body>
<header class="header" id="header">
    <nav class="nav container">
        <a href="#" class="nav__logo">
            <i class="ri-leaf-line nav__logo-icon"></i> BlueLeaf
        </a>

        <div class="nav__menu" id="nav-menu">
            <ul class="nav__list">
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link active-link">Home</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">About</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">Products</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FAQs</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FEEDBACK</a>
                </li>
            </ul>

            <div class="nav__close" id="nav-close">
                <i class="ri-close-line"></i>
            </div>
        </div>

        <div class="nav__btns">
            <!-- Theme change button -->
            <i class="ri-moon-line change-theme" id="theme-button"></i>

            <div class="nav__toggle" id="nav-toggle">
                <i class="ri-menu-line"></i>
            </div>
        </div>
    </nav>
</header>
    <div class="sectionPlant">
        <div class="text">
            <h1>Aloe Vera Plant</h1>
            <!-- <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Modi voluptates, porro exercitationem quod recusandae, voluptatem maiores facere cumque nesciunt atque deleniti incidunt fugiat minus. Sit, architecto! Optio mollitia nobis animi libero dolore tenetur? Amet! -->
                <details>
                    <summary>Description</summary>
                    <p>The aloe vera plant is an easy, attractive succulent that makes for a great indoor companion. Aloe vera plants are useful, too, as the juice from their leaves can be used to relieve pain from scrapes and burns when applied topically. </p>
</details>
<details>
                    <summary>Care Guide</summary>
                    <p>Aloe vera is a succulent plant species of the genus Aloe. The plant is stemless or very short-stemmed with thick, greenish, fleshy leaves that fan out from the plant’s central stem. The margin of the leaf is serrated with small teeth. <br>

Before you buy an aloe, note that you’ll need a location that offers bright, indirect sunlight (or artificial sunlight). Direct sunlight can dry out the plant too much and turn its fleshy leaves yellow, so you may need to water more often if your aloe lives in an especially sunny spot.<br>

Keep the aloe vera plant in a pot near a kitchen window for periodic use.</p>
</details>
<details>
                    <summary>Sad plant sign</summary>
                    <p>Your aloe's leaves should be plump, firm, and upright, with an even green color. If the leaves look droopy, shriveled, or have brown or dead parts, you've got an unhappy plant. But most of the time, you can fix the problem and restore your aloe to health. The most common problem with aloes is overwatering.
</p>
</details>
        </div>
        <img src="assets/img/plant3.jpg" alt=""/>
    </p>
    </div>
</body>
</html>