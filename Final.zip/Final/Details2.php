<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parlor Palm Plant</title>
    <link rel="stylesheet" href="assets/css/plantstyle.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/newstyles.css">
</head>
<body>
<header class="header" id="header">
    <nav class="nav container">
        <a href="#" class="nav__logo">
            <i class="ri-leaf-line nav__logo-icon"></i> BlueLeaf
        </a>

        <div class="nav__menu" id="nav-menu">
            <ul class="nav__list">
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link active-link">Home</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">About</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">Products</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FAQs</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FEEDBACK</a>
                </li>
            </ul>

            <div class="nav__close" id="nav-close">
                <i class="ri-close-line"></i>
            </div>
        </div>

        <div class="nav__btns">
            <!-- Theme change button -->
            <i class="ri-moon-line change-theme" id="theme-button"></i>

            <div class="nav__toggle" id="nav-toggle">
                <i class="ri-menu-line"></i>
            </div>
        </div>
    </nav>
</header>
    <div class="sectionPlant">
        <div class="text">
            <h1>Parlor Palm</h1>
            <!-- <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Modi voluptates, porro exercitationem quod recusandae, voluptatem maiores facere cumque nesciunt atque deleniti incidunt fugiat minus. Sit, architecto! Optio mollitia nobis animi libero dolore tenetur? Amet! -->
                <details>
                    <summary>Description</summary>
                    <p>The Parlor Palm is a favorite easy-care palm with tropical fronds known for its air-purifying qualities. 

Each plant is unique; size and shape fluctuate by season so all measurements are shown as a range</p>
</details>
<details>
                    <summary>Care Guide</summary>
                    <p>Thrives in medium to bright indirect light, but can tolerate low indirect light. Not suited for intense, direct sun.

Water every 1-2 weeks, allowing soil to dry out between waterings. Expect to water more often in brighter light and less often in lower light. This plant can benefit from extra humidity.</p>
</details>
<details>
                    <summary>Sad plant sign</summary>
                    <p>Parlor palms may start to wither or die if their needs are not being met or properly balanced. If you notice brown or yellowing leaves, it could mean: Too much or not enough watering. Not enough humidity
</p>
</details>
        </div>
        <img src="assets/img/plant2.jpg" alt=""/>
    </p>
    </div>
</body>
</html>