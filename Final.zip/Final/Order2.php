<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Order.css">
    <title>Order Spider Plant</title>

  </head>
  <body>
  <header class="header" id="header">
    <nav class="nav container">
        <a href="#" class="nav__logo">
            <i class="ri-leaf-line nav__logo-icon"></i> BlueLeaf
        </a>

        <div class="nav__menu" id="nav-menu">
            <ul class="nav__list">
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link active-link">Home</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">About</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">Products</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FAQs</a>
                </li>
                <li class="nav__item">
                    <a href="/Final/index.php" class="nav__link">FEEDBACK</a>
                </li>
            </ul>

            <div class="nav__close" id="nav-close">
                <i class="ri-close-line"></i>
            </div>
        </div>



    </nav>
</header>

<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $adr = $_POST['adr'];
        $phone = $_POST['phone'];
        $bikash = $_POST['bikash'];
        
      
      // Connecting to the Database
      $servername = "localhost";
      $username = "root";
      $password = "";
      $database = "plantorder";

      // Create a connection
      $conn = mysqli_connect($servername, $username, $password, $database);
      // Die if connection was not successful
      if (!$conn){
          die("Sorry we failed to connect: ". mysqli_connect_error());
      }
      else{ 
        // Submit these to a database
        // Sql query to be executed 
        //  $sql = "INSERT INTO `cactiorder` (`Name`, `Email`, `Address`, `Phone`,`Bikash`) VALUES ('$name', '$email', '$adr', '$phone','$bikash')";

        $sql="INSERT INTO `parlor` ( `Name`, `Email`, `Address`, `Phone No`, `Bikash`) VALUES ('$name','$email', '$adr', '$phone', '$bikash')";
        $result = mysqli_query($conn, $sql);
 
        if($result){
          echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>Success!</strong> Your entry has been submitted successfully!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>';
        }
        else{
            // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>';
        }

      }

    }

    
?>
<hr>
<div class="sectionOr">
<div class="container mt-3">

    <form action="/Final/Order2.php" method="post">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" name="name" class="form-control" id="name" aria-describedby="emailHelp">
    </div>

    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp"> 
        <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
    </div>

    <div class="form-group">
        <label for="adr">Address</label>
        <textarea class="form-control" name="adr" id="adr" cols="30" rows="5"></textarea> 
    </div>

    <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="number" name="phone" class="form-control" id="phone" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
        <label for="bikash">Transaction ID</label>
        <input type="text" name="bikash" class="form-control" id="bikash" aria-describedby="emailHelp">
    </div>
    <h4>A confirmation message will be sent to your email </h4>    
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
  </body>
</html>

